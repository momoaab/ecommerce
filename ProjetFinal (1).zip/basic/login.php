

<?=template_header_login('login')?>

<style> 

.btn {
    text-decoration: none;
    background: #4b505c;
    border: 0;
    color: #FFFFFF;
    padding: 11px 16px;
    font-size: 14px;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
}

.form-field {
    width: 100%;
    padding: 10px;
    border: 1px solid #d5d5d5;
    border-radius: 4px;
    background-color: #fff;
    
}

.login-register {
    display: flex;
    width: 100%;
    justify-content: space-between;
    margin-top: 40px;
}
.register {
    width: 100%;
    padding-left: 45px;
    
}
.login {
    width: 100%;
    border-right: 1px solid #f6f6f6;
    padding-right: 45px;
}
.content-wrapper {
    width: 1050px;
    margin: 0 auto;
    
    
}
</style>

<?php


if (isset($_POST['login'], $_POST['email'], $_POST['password']) ) {
    
    $stmt = $pdo->prepare('SELECT * FROM accounts WHERE email = ? and password = ?');
    $stmt->execute([ $_POST['email'],$_POST['password']]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($account) {

            
            header('location: index.php?page=home');

        
    } else {
        $error = 'Incorrect Email/Password!';
    }
}


if (isset($_POST['register'], $_POST['email'], $_POST['password'], $_POST['cpassword']) ) {
    
    $stmt = $pdo->prepare('SELECT * FROM accounts WHERE email = ?');
    $stmt->execute([ $_POST['email'] ]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($account) {
        
        $register_error = 'Account already exists with that email!';
    } else if ($_POST['cpassword'] != $_POST['password']) {
        $register_error = 'Passwords do not match!';
    }
    else {
        
        $stmt = $pdo->prepare('INSERT INTO accounts (email, password, first_name, last_name, address) VALUES (?,?,"","","")');
        
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt->execute([ $_POST['email'], $password ]);
        $account_id = $pdo->lastInsertId();


            
            header('location: index.php?page=home');
        exit;
    }
}

?>


<div class="myaccount content-wrapper">
<div class="login-register" >

        <div class="login">

            <h1 style="margin-bottom: 30px;">Login</h1>

            <form action="" method="post">

                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" placeholder="doha@example.com" required class="form-field" style="margin-bottom: 20px;">

                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" placeholder="Password" required class="form-field" style="margin-bottom: 20px;">

                <input name="login" type="submit" value="Login" class="btn">

            </form>



        </div>

        <div class="register">

            <h1 style="margin-bottom: 30px;">Register</h1>

            <form action="" method="post">

                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" placeholder="doha@example.com" required class="form-field" style="margin-bottom: 20px;">

                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" placeholder="Password" required class="form-field" style="margin-bottom: 20px;">

                <label for="cpassword" class="form-label">Confirm Password</label>
                <input type="password" name="cpassword" id="cpassword" placeholder="Confirm Password" required class="form-field" style="margin-bottom: 20px;">

                <input name="register" type="submit" value="Register" class="btn">

            </form>



        </div>

    </div>
    </div>



<?=template_footer()?>