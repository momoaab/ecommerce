<?php

if (isset($_GET['query']) && $_GET['query'] != '') {
    
    $search_query = htmlspecialchars($_GET['query'], ENT_QUOTES, 'UTF-8');
    
    $req = $pdo->prepare('SELECT * FROM products WHERE name LIKE ? ORDER BY date_added DESC');
    
    $req->execute(['%' . $search_query . '%']);
    
    $products = $req->fetchAll(PDO::FETCH_ASSOC);
    
    $total_products = count($products);
} else {
    
    die ('No search query was specified!');
}
?>

<?=template_header('Search')?>

<div class="products content-wrapper">
    <h1>Search Results for "<?=$search_query?>"</h1>
    <p><?=$total_products?> Products</p>
    <div class="products-wrapper">
        <?php foreach ($products as $product): ?>
        <a href="index.php?page=product&id=<?=$product['id']?>" class="product">
            <img src="imgs/<?=$product['img']?>" width="200" height="200" alt="<?=$product['name']?>">
            <span class="name"><?=$product['name']?></span>
            <span class="price">
                &dollar;<?=$product['price']?>
                <?php if ($product['rrp'] > 0): ?>
                <span class="rrp">&dollar;<?=$product['rrp']?></span>
                <?php endif; ?>
            </span>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<?=template_footer()?>
